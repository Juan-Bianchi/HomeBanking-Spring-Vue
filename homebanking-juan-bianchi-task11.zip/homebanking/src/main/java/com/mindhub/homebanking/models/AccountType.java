package com.mindhub.homebanking.models;

public enum AccountType {
    SAVINGS,
    CURRENT,
}
